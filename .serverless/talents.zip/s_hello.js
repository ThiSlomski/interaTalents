
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'thiagoslomski',
  applicationName: 'intera-case',
  appUid: 'VnFWDw31fsGCW4XgKc',
  orgUid: 'e26e68de-a124-4f7e-88ca-f1504563c6aa',
  deploymentUid: '4e3b39da-56b5-4baa-88ec-2d23e827e69c',
  serviceName: 'talents',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'talents-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}